#!/bin/bash
echo copy lostener to /usr/local/bin/
cp ./listener.sh /usr/local/bin/
echo set permissions 
chmod 777 /usr/local/bin/listener.sh
echo run script
sh /usr/local/bin/listener.sh
echo register cron
echo "@reboot /usr/local/bin/listener.sh" > /var/spool/cron/crontabs/root