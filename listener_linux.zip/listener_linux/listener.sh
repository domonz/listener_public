#!/bin/bash

nc -k -l 1080&